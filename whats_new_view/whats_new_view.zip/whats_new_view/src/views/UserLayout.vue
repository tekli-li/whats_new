<script setup>
    import {
    Management,
    Promotion,
    UserFilled,
    User,
    Crop,
    EditPen,
    SwitchButton,
    CaretBottom
} from '@element-plus/icons-vue'
import avatar from '@/assets/default.png'
</script>

<template>
    <el-container class="user-layout-container">
        <el-header>
            <el-col>
                <el-menu mode="horizontal" background-color="#333" text-color="#fff" active-text-color="#ffd04b">
                <el-menu-item index="1">推荐</el-menu-item>
                <el-menu-item index="2">分类</el-menu-item>
                <el-menu-item index="3">收藏</el-menu-item>
                <el-menu-item index="4">历史</el-menu-item>
                </el-menu>
                <el-input placeholder="搜索..." style="width: 200px;"></el-input>
                <el-button type="primary">搜索</el-button>
            </el-col>
        </el-header>
    </el-container>
</template>

<style>

</style>